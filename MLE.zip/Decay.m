function [new_opt,std_dev] = Decay (h,IRF,tau1,gamma,bg,opt,plot_op)
%this function will optimize a parameter using the MLE method for the
%function exp(-t/tau1) by convoluting this function with
%the IRF and comparing with the fluorescent decay profile h

%bg is the bg level added to the convolution to imrprove the fit
%bgr is a value between 0 and 1 which bg is multiplied by when added

%opt specifies which parameter is being optimized 
% 1 - tau1 (ranges from 0.01 to 3)
% 2 - bgr (ranges from 0 to 1)
% 3 - shift (ranges from -100 to 100), this is the amount the IRF is shifted w.r.t the signal 

%if other values are desired they can be manually changed

%plot_op specifies whether a plot should be generated showing the fit and
%log(likelihood) 

%new_opt will return the parameter optimized

bin_time = 0.004*3125/length(h);

channels = 12.5/bin_time;
time = linspace(0,12.5,channels);

% %for Crystal's data 
% channels = 12.5/0.02;
% time = linspace(0,12.5,channels);

totalphoton = sum(h);

if opt == 1
tau1v = 0.01:0.01:5; %values of tau1 which are iterated over
    k=0;
    for tau1=0.01:0.01:5
        k = k+1;   

        ex = exp((-time)/tau1) ; %generate exponential
        convolution = conv(IRF,ex); %convolve with IRF
        convolution = convolution./sum(convolution);
        nconvolution = (1-gamma)*(convolution(1:channels)) +gamma*bg/sum(bg) ; %normalize by sum and add bg term    
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(k) = L; %save L into vector 

    end

%find best tau1
[pks,locs] = findpeaks(real(log(tempL)));  %find peak of tempL -> corresponds to optimal value  

if isempty(pks) %if optimum occurs at minimum, use min instead
     [pks, locs] = min(real(log(tempL)));
 end

tau1 = tau1v(locs);
 
    if length(tau1) >1 %if more than one peak is present, user must select peak
        figure; hold on
        plot(tau1v, log(tempL)); plot(tau1v(locs),pks,'o')
        title('Select Tau1 or 0 for min')
        t1num = input('Select point ') ;
        
        if t1num ~= 0 
            tau1 = tau1(t1num);
        end
        
    if t1num == 0 
       [pks,locs] = min(real(log(tempL)));
        tau1 = tau1v(locs);
    end    
     close
    
    end

new_opt = tau1; %save best value as new_opt
tau1 = new_opt;

vals = tau1v; %values for log(likelihood) plot

  std_dev = cramer_rao(vals,tempL,new_opt);


end



% if opt == 2
% bgrv = 0:0.01:10; %values of bgr which are iterated over
%     k=0;
%     for bgr=0:0.01:10
%         k = k+1;   
% 
%         ex = exp((-time)/tau1) ; %generate exponential
%         convolution = conv(IRF,ex); %convolve with IRF
%         convolution = convolution./sum(convolution);
%         nconvolution = (1-gamma)*(convolution(1:channels))./(sum(convolution(1:channels))) +gamma*bg/sum(bg) ; %normalize by sum and add bg term   
%         
%         L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
%         tempL(k) = L; %save L into vector 
% 
%     end
% 
% [pks,locs] = findpeaks(real(log(tempL)),'MinPeakWidth',0.01); %find peak of tempL -> corresponds to optimal value 
% 
%  if isempty(pks) %bgr may not find peak, use min instead
%      [pks, locs] = min(real(log(tempL)));
%  end
% 
% new_opt = bgrv(locs); %save best value as new_opt
% bgr = new_opt;
% 
% vals = bgrv; %values for log(likelihood) plot
% end


if opt == 3
shiftv = -100:1:100; %values of shift which are iterated over
    k=0;
    for shift=-100:1:100
        k = k+1;   

        ex = exp((-time)/tau1) ; %generate exponential
        convolution = conv(circshift(IRF,shift),ex); %convolve with IRF
        convolution = convolution./sum(convolution);
        nconvolution = (1-gamma)*(convolution(1:channels)) +gamma*bg/sum(bg) ; %normalize by sum and add bg term   
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(k) = L; %save L into vector 

    end

[pks,locs] = findpeaks(real(log(tempL)),'MinPeakWidth',0.01); %find peak of tempL -> corresponds to optimal value 

 if isempty(pks)  %bgr may not find peak, use min instead
     [pks, locs] = min(real(log(tempL)));
 end


new_opt = shiftv(locs); %save best value as new_opt
shift = new_opt;

IRF = circshift(IRF,shift);

vals = shiftv; %values for log(likelihood) plot
end


if plot_op == 1 %user wishes to plot
    
figure

subplot(2,1,2); hold on

plot(vals, log(tempL)); plot(vals(locs),pks,'o')

subplot(2,1,1); hold on

title(['Exp(-t/' num2str(tau1) ')' ])

plot(time,h./totalphoton)

ex = exp((-time)./tau1) ;
convolution = conv(IRF,ex);
convolution = convolution./sum(convolution);
nconvolution = (1-gamma)*(convolution(1:channels)) +gamma*bg./sum(bg) ; %normalize by sum and add bg term   

plot(time,max(nconvolution).*IRF./max(IRF)) %plot IRF normalized by max of convolution
plot(time,nconvolution,'k')




end