function [new_opt] = Rise_and_Decay (h,IRF,tau1,tau2,A,bgr,bg,opt,plot_op)

% global vals
% global tempL
%this function will optimize a parameter using the MLE method for the
%function exp(-t/tau1) - A*exp(t/tau2) by convoluting this function with
%the IRF and comparing with the fluorescent decay profile h

%bg is the bg level added to the convolution to imrprove the fit
%bgr is a value between 0 and 1 which bg is multiplied by when added

%opt specifies which parameter is being optimized 
% 1 - tau1 (ranges from 0.01 to 3)
% 2 - tau2 (ranges from 0.01 to 2)
% 3 - A (ranges from 0.01 to 1)
% 4 - bgr (ranges from 0 to 1)
% 5 - shift (ranges from -100 to 100), this is the amount the IRF is shifted w.r.t the signal 

%if other values are desired they can be manually changed

%plot_op specifies whether a plot should be generated showing the fit and
%log(likelihood) 

%new_opt will return the parameter optimized
% clear global vals  ; clear global tempL

bin_time = 0.004*3125/length(h);

channels = 12.5/bin_time;
time = linspace(0,12.5,channels);
totalphoton = sum(h);

%for Crystal's data 
% channels = 12.5/0.02;
% time = linspace(0,12.5,channels);

if opt == 1
tau1v = 0.01:0.01:5; %values of tau1 which are iterated over
    k=0;
    for tau1=0.01:0.01:5
        k = k+1;   

        ex = exp((-time)/tau1) -A*exp(-time/tau2); %generate exponential
        convolution = conv(IRF,ex); %convolve with IRF
        nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ; %normalize by sum and add bg term   
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(k) = L; %save L into vector 

    end

%find best tau1
[pks,locs] = findpeaks(real(log(tempL)));  %find peak of tempL -> corresponds to optimal value  
tau1 = tau1v(locs);
%std_dev = sqrt(1./pks);

%     if length(tau1) ==1 %only one peak is present make sure this is desired one (don't want min instead)
%         
%     end
    
    %if length(tau1) >1 %if more than one peak is present, user must select peak
       % clear std_dev %more than 1 value assigned to std_dev, clear and find value based on selected point
        figure; hold on
        plot(tau1v, log(tempL)); plot(tau1v(locs),pks,'o')
        title('Select Tau1 or 0 for min')
        t1num = input('Select point ') ;
        
        if t1num ~= 0 
            tau1 = tau1(t1num);
            %std_dev = sqrt(1/pks(t1num));
        end
        
    if t1num == 0 
       [pks,locs] = min(real(log(tempL)));
        tau1 = tau1v(locs);
        %std_dev = sqrt(1/pks);
    %end    
    end
          close
          
new_opt = tau1; %save best value as new_opt
tau1 = new_opt;


vals = tau1v; %values for log(likelihood) plot
end


if opt == 2
tau2v = 0.01:0.01:2; %values of tau2 which are iterated over
    k=0;
    for tau2=0.01:0.01:2
        k = k+1;   

        ex = exp((-time)/tau1) -A*exp(-time/tau2); %generate exponential
        convolution = conv(IRF,ex); %convolve with IRF
        nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ; %normalize by sum and add bg term   
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(k) = L; %save L into vector 

    end

%find peak of tempL -> corresponds to optimal value 
[pks,locs] = findpeaks(real(log(tempL)));

 if isempty(pks) %If peak not found, use min instead
     [pks, locs] = min(real(log(tempL)));  
%      plot_op = 1;
 end


tau2 = tau2v(locs);
%std_dev = sqrt(1./pks);

%      if length(tau2) >1 %if more than one peak is present, user must select peak
%         clear std_dev %more than 1 value assigned to std_dev, clear and find value based on selected point
        figure; hold on
        plot(tau2v, log(tempL)); plot(tau2v(locs),pks,'o')
        title('Select Tau2 or 0 for min')
        t2num = input('Select point ') ;
        
     
     
     if t2num < 0 
         [pks, locs] = ginput(1); %point you want isn't absolute min
         tau2 = pks;
     elseif t2num ~= 0 
            tau2 = tau2(t2num);
            %std_dev = sqrt(1/pks(t2num));
            
     elseif t2num == 0 
       [pks,locs] = min(real(log(tempL)));
        tau2 = tau2v(locs);
        %std_dev = sqrt(1/pks);
     end    
     close
    
%      end
  

    
new_opt = tau2; %save best value as new_opt

vals = tau2v; %values for log(likelihood) plot
end

if opt == 3
Av = 0:0.01:1; %values of A which are iterated over
    k=0;
    for A=0:0.01:1
        k = k+1;   

        ex = exp((-time)/tau1) -A*exp(-time/tau2); %generate exponential
        convolution = conv(IRF,ex); %convolve with IRF
        nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ; %normalize by sum and add bg term   
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(k) = L; %save L into vector 

    end

%find peak of tempL -> corresponds to optimal value 
[pks,locs] = findpeaks(real(log(tempL)));


 if isempty(pks) %A may not find peak, use min instead
     [pks, locs] = min(real(log(tempL)));  
 end
 
A = Av(locs);

    if length(A) >1 %if more than one peak is present, user must select peak
        figure; hold on
        plot(Av, log(tempL)); plot(Av(locs),pks,'o')
        title('Select A or 0 for min')
        Anum = input('Select point ') ;
        
        if Anum ~= 0 
            A = A(Anum);
            %std_dev = sqrt(1/pks(Anum));
        end
        
    if Anum == 0
       [pks,locs] = min(real(log(tempL)));
        A = Av(locs);
        %std_dev = sqrt(1/pks);
    end 
        close
    end
  
   if A == 1
        [pks,locs] = min(real(log(tempL)));
        A = Av(locs); 
    end
    
    
new_opt = A; %save best value as new_opt
vals = Av; %values for log(likelihood) plot
end


if opt == 4
bgrv = 0:0.01:10; %values of bgr which are iterated over
    k=0;
    for bgr=0:0.01:10
        k = k+1;   

        ex = exp((-time)/tau1) -A*exp(-time/tau2); %generate exponential
        convolution = conv(IRF,ex); %convolve with IRF
        nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ; %normalize by sum and add bg term   
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(k) = L; %save L into vector 

    end

[pks,locs] = findpeaks(real(log(tempL))); %find peak of tempL -> corresponds to optimal value 

 if isempty(pks) %bgr may not find peak, use min instead
     [pks, locs] = min(real(log(tempL)));
 end

new_opt = bgrv(locs); %save best value as new_opt
bgr = new_opt;

vals = bgrv; %values for log(likelihood) plot
end


if opt == 5
shiftv = -100:1:100; %values of bgr which are iterated over
    k=0;
    for shift=-100:1:100
        k = k+1;   

        ex = exp((-time)/tau1) -A*exp(-time/tau2) ; %generate exponential
        convolution = conv(circshift(IRF,shift),ex); %convolve with IRF
        nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ; %normalize by sum and add bg term   
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(k) = L; %save L into vector 

    end

[pks,locs] = findpeaks(real(log(tempL))); %find peak of tempL -> corresponds to optimal value 

 if isempty(pks)  %bgr may not find peak, use min instead
     [pks, locs] = min(real(log(tempL)));
 end


new_opt = shiftv(locs); %save best value as new_opt
shift = new_opt;

IRF = circshift(IRF,shift);

vals = shiftv; %values for log(likelihood) plot
end


if plot_op == 1 %user wishes to plot
    
figure

subplot(2,1,2); hold on

plot(vals, log(tempL)); plot(vals(locs),pks,'o')

subplot(2,1,1); hold on

title(['Exp(-t/' num2str(tau1) ') -' num2str(A) ' Exp(-t/' num2str(tau2) ')'])

plot(time,h./totalphoton)

ex = exp((-time)./tau1) - A*exp(-time./tau2);
convolution = conv(IRF,ex);
nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ;

plot(time,max(nconvolution).*IRF./max(IRF)) %plot IRF normalized by max of convolution
plot(time,nconvolution,'k')


 st_dev = cramer_rao(vals,tempL,new_opt)

end



if opt == 6
tau2v = 0.01:0.01:3; 
Av = 0:0.01:1; %values of A which are iterated over
    
 k=0; j=0;    
    for tau2 = 0.01:0.01:3
        k=0; 
        j = j+1;
    for A=0:0.01:1
        k = k+1;   

        ex = exp((-time)/tau1) -A*exp(-time/tau2); %generate exponential
        convolution = conv(IRF,ex); %convolve with IRF
        nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ; %normalize by sum and add bg term   
    
        L = sum((h.*log(h./(totalphoton*nconvolution)))); %calculate likelihood function
        tempL(j,k) = L; %save L into vector 

    end
    end
    
    
% %find peak of tempL -> corresponds to optimal value 
% [pks,locs] = findpeaks(real(log(tempL)));
% 
% 
%  if isempty(pks) %A may not find peak, use min instead
%      [pks, locs] = min(real(log(tempL)));  
%  end
%  
% A = Av(locs);
% %std_dev = sqrt(1/pks);
% 
%     if length(A) >1 %if more than one peak is present, user must select peak
%         figure; hold on
%         plot(Av, log(tempL)); plot(Av(locs),pks,'o')
%         title('Select A or 0 for min')
%         Anum = input('Select point ') ;
%         
%         if Anum ~= 0 
%             A = A(Anum);
%             %std_dev = sqrt(1/pks(Anum));
%         end
%         
%     if Anum == 0
%        [pks,locs] = min(real(log(tempL)));
%         A = Av(locs);
%         %std_dev = sqrt(1/pks);
%     end 
%         close
%     end
%   
% 
%     
%     
% new_opt = A; %save best value as new_opt
% vals = Av; %values for log(likelihood) plot

new_opt = tempL;

end





end