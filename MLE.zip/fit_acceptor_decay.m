%This script will fit acceptor rise and decays using a function of the form
%exp(-t/tau1)
warning('off','all')
% plot_op = 0;

bin_time = 0.004;

channels = 12.5/bin_time;
time = linspace(0,12.5,channels);

%ha generated from jesse_test_code2 will be fit
 h=ha;

%the IRF is selected from a file specificed here
load('IRF-nobandpass.mat')
IRF = histograms(:,1);

% h = smooth(smooth(smooth(smooth(smooth(ha)))))';

if bin_time ~= 0.004
    
%make sure time and h are the same length 
while length(time) ~= length(h)
    h(end) = [];
end    
    
    
a = bin_time/0.004;    
IRF2 = zeros(1,length(h));
% h2 = zeros(1,12.5/0.02);

b = a-1;

% this looks complicated but basically it just rebins the IRF if the bin
% size is larger than 4 ps 
for j=1:length(IRF2)
   IRF2(j) = sum(IRF(a*j-b:a*j));
%    h2(j) = sum(h(5*j-4:5*j)); 
end

IRF=IRF2;

end

%correct first and last few bins in ha and IRF
for i=4:-1:1
if h(end-i) > 4*h(end-i+1)
    h(end-i+1) = h(end-i);
end
end

for i=4:-1:1
if IRF(end-i) > 4*IRF(end-i+1)
    IRF(end-i+1) = IRF(end-i);
end
end

for i=4:-1:1
if IRF(i+1) > 4*IRF(i)
    IRF(i) = IRF(i+1);
end
end

%remove zeros from h to minimize issues
for z=1:length(h)-1
    if h(z) ==0
        h(z) = (h(z+1)+h(z-1))/2;
    end
    
end
 

%remove zeros from IRF to minimize issues
for z=1:length(IRF)-1
    if IRF(z) ==0
        IRF(z) = (IRF(z+1)+IRF(z-1))/2;
    end
    
end
%shift IRF down
IRF = IRF-min(IRF);


%optimize position of IRF for acceptor
if bin_time == 0.004
    IRF = circshift(IRF,355);
else
    IRF = circshift(IRF,round(355/(bin_time/0.004)));
end



% %find background 
% %background will be region while large than IRF
% clear bg %just in case runnning multile files, don't want to not trigger isnan if needed
% 
% for nbg=1:length(h)
% if h(nbg) < IRF(nbg)*(max(h)./max(IRF))
%    break 
% end
% end
% 
% bg = mean(h(1:nbg-1));
% 
% %if for whatever reason signal is lower/less noisy than IRF, generate bg
% %level with first few points in h
% if isnan(bg) == 1
%    bg = mean(h(1:40));
% end
% 
% totalphoton = sum(h);
% 
% bg = bg/(bin_time/0.004);

 load('C:\Users\Jesse\Documents\Data\2017-06-12\2017-06-12\TTTR\background.mat')
bg = histograms(:,1);
bg = bg';


bg(1) = bg(2);
bg(end-1) = bg(end-2); bg(end) = bg(end-2);

bg = bg-min(bg);

%move bg to same spot as IRF
[~,y1] = max(IRF);
[~,y2] = max(bg);

bg = circshift(bg,y1-y2);


gamma = 18.1495/90.3171;




%use this to fit fake data

tx = 1.3; 


fake = exp(-time/tx) ;

fake = conv(IRF,fake);

fake = fake./sum(fake);

h = (1-gamma)*(fake(1:channels)) +gamma*bg./sum(bg);



% %add noise

 noise = 100;

for ii = 1:length(h)
   h(ii) = h(ii) + randn*(sqrt(h(ii)))/(noise); 

 end

h = abs(h);


% figure
% plot(time, h)
% 
% keyboard






plot_op = 1;


[tau1] = Decay(h,IRF,0,gamma,bg,1,plot_op); %optmize tau1 using mono-exp decay function

 for jj = 1:3
  [shift] = Decay (h,IRF,tau1,gamma,bg,3,plot_op);
  IRF = circshift(IRF,shift);
[tau1] = Decay(h,IRF,tau1,gamma,bg,1,plot_op);
%  [bgr] = Decay (h,IRF,tau1,bgr,bg,2,plot_op);

%  [tau1] = Decay(h,IRF,tau1,gamma,bg,1,plot_op);
 end
 
 
 
 plot_op = 0;
 
 [tau1,std_dev] = Decay(h,IRF,tau1,gamma,bg,1,plot_op);
%  end
% plot_op = 0; 
% 
%  [tau1] = Decay(h,IRF,0,bgr,bg,1,plot_op);
%  
%   [tau1,std_dev] = Decay (h,IRF,tau1,bgr,bg,1,plot_op);
%   
%   tau1 = tau1 + std_dev;
% 
%    [bgr] = Decay (h,IRF,tau1,bgr,bg,2,plot_op);
%    
% %    plot_op = 0;
%    
%  [tau1,std_dev] = Decay (h,IRF,tau1,bgr,bg,1,plot_op);
%   keyboard
%  A=0.5;
% %   tau1 = tau1-0.5;
% 
% [tau2] = Decay_and_Decay(h,IRF,tau1,0,A,bgr,bg,2,plot_op); %optmize tau2
% 
% [A] = Decay_and_Decay(h,IRF,tau1,tau2,0.5,bgr,bg,3,plot_op); %optimize A
% 
%  [tau1] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);
% 
% [tau2] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2
% 
% [A] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A
% 
%  [tau1] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);
% 
% [tau2] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2
% 
% [A] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A
% 
%  [tau1] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);
% 
% [tau2] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2
% 
% [A] = Decay_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A
%  
%  std_dev ;
 
 %for very noisy plots, lifetime is underestimated so add std dev if large
%  if std_dev > 0.01 
%       tau1 = round(tau1 + std_dev/sqrt(2),2);
%  end
 
figure  
hold on

plot(time,h)

ex = exp((-time)/tau1) ;
% ex = exp((-time)/tau1)  +A*exp(-time/tau2);
convolution = conv(IRF,ex);
convolution = convolution./sum(convolution);
nconvolution = (1-gamma)*(convolution(1:channels)) +gamma*bg./sum(bg) ; %normalize by sum and add bg term   

plot(time,max(nconvolution).*IRF./max(IRF)) %plot IRF normalized by max of convolution
plot(time,nconvolution,'k')

% title(['Exp(-t/' num2str(tau1) ') bgr = ' num2str(bgr)])

title(['Exp(-t/' num2str(tau1)  ') std dev = ' num2str(std_dev) ])

%   title(['Actual: Exp(-t/' num2str(tx) ')' ,...
%       ' Fit: Exp(-t/' num2str(tau1) ')' ])
% title(['Exp(-t/' num2str(tau1) ') +' num2str(A) ' Exp(-t/' num2str(tau2) ')  bgr = ' num2str(bgr)])
% 
%  title(['Actual: Exp(-t/' num2str(tx) ') +' num2str(ty) ' Exp(-t/' num2str(tz) ')' ,...
%      ' Fit: Exp(-t/' num2str(tau1) ') +' num2str(A) ' Exp(-t/' num2str(tau2) ')  bgr = ' num2str(bgr)])