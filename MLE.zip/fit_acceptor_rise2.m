%This script will fit acceptor rise and decays using a function of the form
%exp(-t/tau1) - A*exp(-t/tau2)
warning('off','all')
% plot_op = 0;

bin_time = 0.004;

channels = 12.5/bin_time;
time = linspace(0,12.5,channels);

%ha generated from jesse_test_code2 will be fit
h=ha;

%the IRF is selected from a file specificed here
load('IRF-nobandpass.mat')
IRF = histograms(:,1);

% h = smooth(smooth(smooth(smooth(smooth(ha)))))';

if bin_time ~= 0.004
    
%make sure time and h are the same length 
while length(time) ~= length(h)
    h(end) = [];
end    
    
    
a = bin_time/0.004;    
IRF2 = zeros(1,length(h));
% h2 = zeros(1,12.5/0.02);

b = a-1;

% this looks complicated but basically it just rebins the IRF if the bin
% size is larger than 4 ps 
for j=1:length(IRF2)
   IRF2(j) = sum(IRF(a*j-b:a*j));
%    h2(j) = sum(h(5*j-4:5*j)); 
end

IRF=IRF2;

end

%correct first and last few bins in ha and IRF
for i=4:-1:1
if h(end-i) > 4*h(end-i+1)
    h(end-i+1) = h(end-i);
end
end

for i=4:-1:1
if IRF(end-i) > 4*IRF(end-i+1)
    IRF(end-i+1) = IRF(end-i);
end
end

for i=4:-1:1
if IRF(i+1) > 4*IRF(i)
    IRF(i) = IRF(i+1);
end
end

%remove zeros from h to minimize issues
for z=1:length(h)-1
    if h(z) ==0
        h(z) = (h(z+1)+h(z-1))/2;
    end
    
end
 

%remove zeros from IRF to minimize issues
for z=1:length(IRF)-1
    if IRF(z) ==0
        IRF(z) = (IRF(z+1)+IRF(z-1))/2;
    end
    
end
%shift IRF down
IRF = IRF-min(IRF);


%optimize position of IRF for acceptor
if bin_time == 0.004
    IRF = circshift(IRF,355);
else
    IRF = circshift(IRF,round(355/(bin_time/0.004)));
end

%use this to fit fake data

%  tx = 1.8; ty = 0.4; tz = 0.2;
% 
% 
% fake = exp(-time/tx) - ty*exp(-time/tz);
% 
% fake = conv(IRF,fake);
% 
% h = (fake(1:channels))./(sum(fake(1:channels)));
% 
% 
% 
% fake2 = exp(-time/tx) ;%- ty*exp(-time/(0.3));
%  
%  fake2 = conv(IRF,fake2);
% 
% h2 = (fake2(1:channels))./(sum(fake2(1:channels))) ;
% % 
% % fake3 = exp(-time/tx);
% %  
% %  fake3 = conv(IRF,fake3);
% % 
% % h3 = (fake3(1:channels))./(sum(fake3(1:channels))) ;
% 
% 
% %add noise
% % h = h + randn(size(h))*std(h)/10; %vary division factor to change amount of noise
% % h2 = h2 + randn(size(h2))*std(h2)/10; %vary division factor to change amount of noise
 noise = 1000;
% 
% for ii = 1:length(h)
%    h(ii) = h(ii) + randn*(sqrt(h(ii)))/(noise); 
%      h2(ii) = h2(ii) + randn*(sqrt(h2(ii)))/(noise); 
% %    h3(ii) = h3(ii) + randn(1)*h3(ii)/noise; 
%  end
% % 
% % 
%    figure; hold on; plot(time, log(h)); plot(time, log(h2)); 
%     figure; hold on; plot(time, (h)); plot(time, (h2)); keyboard
% % %   h = h + randn(size(h))*std(h)/(noise);
%     h=abs(h);
% %  
%  h2 = h2 + randn(size(h2))*std(h2)/(noise);
% h2=abs(h2);

%  figure; hold on; plot(time, h); 
%   keyboard

% h = h + max(h)/100;
% h=abs(h);
% 
%  h2 = h2 + randn(size(h2))*std(h2)/noise;
% 
% h2 = h2 + max(h2)/100;
% h2=abs(h2);
% 
%  h3 = h3 + randn(size(h3))*std(h3)/noise;
% 
% h3 = h3 + max(h3)/100;
% h3=abs(h3);



% h2 = h2 + max(h2)/100;
% h2=abs(h2);

% figure; hold on; plot(time,h./max(h)); 
% plot(time,h2./max(h2)) ;% plot(time, h3./max(h3))
% % legend('0.2 ns rise','1.2 ns rise','decay only')
%  keyboard


%shift h down
% h = h - min(h);
% %remove zero from h to minimize issues
% [~,loc] = min(h);
% h(loc) = (h(loc-1)+h(loc+1))/2;


%find background 
%background will be region while large than IRF

for nbg=1:length(h)
if h(nbg) < IRF(nbg)*(max(h)./max(IRF))
   break 
end
end

bg = mean(h(1:nbg-1));

%if for whatever reason signal is lower/less noisy than IRF, generate bg
%level with first few points in h
if isnan(bg) == 1
   bg = mean(h(1:40));
end

totalphoton = sum(h);

bg = bg/(bin_time/0.004);

bgr= 0.2;
A = 0.6;
plot_op = 0;
%  tau1 = 1.8; %value determined from decay of direct excitation of acceptor


%%value from decay fit
% tau1 = 1.45;
% [tau1] = Decay(h,IRF,0,bgr,bg,1,plot_op); %optmize tau1 using mono-exp decay function
% keyboard
%  [shift] = Decay (h,IRF,tau1,bgr,bg,3,plot_op);
%  IRF = circshift(IRF,shift);

% [bgr] = Decay (h,IRF,tau1,bgr,bg,2,plot_op);

%  [tau1] = Decay (h,IRF,tau1,bgr,bg,1,plot_op);

% [new_opt] = Rise_and_Decay(h,IRF,tau1,0,0,bgr,bg,6,0);
% keyboard

[tau2] = Rise_and_Decay(h,IRF,tau1,0,A,bgr,bg,2,plot_op); %optmize tau2

[A] = Rise_and_Decay(h,IRF,tau1,tau2,0.5,bgr,bg,3,plot_op); %optimize A

% [tau1] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);

[tau2] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2

[A] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A

  [shift] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,5,plot_op);
  IRF = circshift(IRF,shift);

[bgr] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,4,plot_op);

plot_op = 0;

for ii=1:3
    
% [tau1] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);

[tau2] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2

[A] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A

[bgr] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,4,plot_op);

[tau2] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2

[A] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A

% [tau1] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);

[tau2] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2

[A] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A

end

% figure  
% hold on
% 
% plot(time,h./totalphoton)
% 
% ex = exp((-time)/tau1) -A*exp(-time/tau2) ;
% convolution = conv(IRF,ex);
% nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ;
% 
% plot(time,max(nconvolution).*IRF./max(IRF)) %plot IRF normalized by max of convolution
% plot(time,nconvolution,'k')
% 
% title(['Exp(-t/' num2str(tau1) ') -' num2str(A) ' Exp(-t/' num2str(tau2) ')  bgr = ' num2str(bgr)])



%  title(['Actual: Exp(-t/' num2str(tx) ') -' num2str(ty) ' Exp(-t/' num2str(tz) ')' ,...
%      ' Fit: Exp(-t/' num2str(tau1) ') -' num2str(A) ' Exp(-t/' num2str(tau2) ')  bgr = ' num2str(bgr)])

%  keyboard
 
% temp_tau1 = tau1;
% temp_tau2 = tau2;
% temp_A = A;
% 
% tau1 = tau1 - 0.1;
%     
% for ii=1:3
%     
% [tau2] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2
% 
% [A] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A
% 
% [bgr] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,4,plot_op);
% 
% [tau2] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2
% 
% [A] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A
% 
% [tau1] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);
% 
% [tau2] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2
% 
% [A] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,3,plot_op); %optimize A
% 
% end
% 
% tau1 = (tau1+temp_tau1)/2;
% tau2 = (tau2+temp_tau2)/2;
% A = (A+temp_A)/2;

it = 0;

jj=0;
plot_op = 0;

while jj == 0
    
% [tau1x] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,1,plot_op);

% [tau2x] = Rise_and_Decay(h,IRF,tau1x,tau2,A,bgr,bg,2,plot_op); %optmize tau2
[tau2x] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op); %optmize tau2

% [Ax] = Rise_and_Decay(h,IRF,tau1x,tau2x,A,bgr,bg,3,plot_op); %optimize A
[Ax] = Rise_and_Decay(h,IRF,tau1,tau2x,A,bgr,bg,3,plot_op); %optimize A

% if tau1x == tau1 && tau2x == tau2 && Ax == A
if tau2x == tau2 && Ax == A
    jj = 1;
end

% tau1 = tau1x;
tau2 = tau2x; A = Ax;

it = it+1;

if it >=10
   break  
end

end
plot_op=1;
[tau2x] = Rise_and_Decay(h,IRF,tau1,tau2,A,bgr,bg,2,plot_op);
close;
% %%final optimization 
% 
% temp_A = A;
% temp_tau1 = tau1; 
% temp_tau2 = tau2;
% temp_check=0; %this will keep it from crashing if the values are already optimal 
% 
% best_diff_sq = sum(((h./totalphoton)-nconvolution).^2);
% 
% for A=temp_A-0.1:0.01:temp_A+0.1
% for tau1=temp_tau1-0.1:0.01:temp_tau1+0.1
% for tau2=temp_tau2-0.1:0.01:temp_tau2+0.1
%     %recalculate everything
%     ex = exp((-time)/tau1) -A*exp(-time/tau2) ;
%     convolution = conv(IRF,ex);
%     nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ;
%     
%  diff_sq = sum(((h./totalphoton)-nconvolution).^2);
%  
%  if diff_sq < best_diff_sq
%      best_A = A;
%      best_tau1 = tau1;
%      best_tau2 = tau2;
%      temp_check = 1;
%      best_diff_sq = diff_sq;
%  end
% 
% end
% end
% end
% 
% if temp_check == 1
%      A = best_A;
%      tau1 = best_tau1;
%      tau2 = best_tau2;
% else 
%      A = temp_A;
%      tau1 = temp_tau1;
%      tau2 = temp_tau2;   
% end
    
    
    

figure  
hold on

plot(time,h./totalphoton)

ex = exp((-time)/tau1) -A*exp(-time/tau2) ;
convolution = conv(IRF,ex);
nconvolution = (convolution(1:channels))./(sum(convolution(1:channels))) +bgr*bg/totalphoton ;

plot(time,max(nconvolution).*IRF./max(IRF)) %plot IRF normalized by max of convolution
plot(time,nconvolution,'k')

title(['Exp(-t/' num2str(tau1) ') -' num2str(A) ' Exp(-t/' num2str(tau2) ')  bgr = ' num2str(bgr)])



%  title(['Actual: Exp(-t/' num2str(tx) ') -' num2str(ty) ' Exp(-t/' num2str(tz) ')' ,...
%      ' Fit: Exp(-t/' num2str(tau1) ') -' num2str(A) ' Exp(-t/' num2str(tau2) ')  bgr = ' num2str(bgr)])